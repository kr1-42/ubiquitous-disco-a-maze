"""
MazeGenerator - A reusable maze generation module.

This module provides a MazeGenerator class that can be used to generate
random mazes using various algorithms (default: Recursive Backtracking).

Installation:
    pip install mazegen-1.0.0-py3-none-any.whl
    # or
    pip install mazegen-1.0.0.tar.gz

Quick Start:
    >>> from mazegen import MazeGenerator
    >>> generator = MazeGenerator(width=10, height=10, seed=42)
    >>> maze = generator.generate()
    >>> solution = generator.solve()
    >>> generator.print_maze()

Classes:
    MazeGenerator: Main class for generating and solving mazes.

Example Usage:
    # Basic usage with default parameters
    from mazegen import MazeGenerator
    
    gen = MazeGenerator()
    gen.generate()
    gen.print_maze()
    
    # Custom size and seed for reproducibility
    gen = MazeGenerator(width=20, height=15, seed=12345)
    gen.generate()
    
    # Access the maze structure
    structure = gen.get_structure()
    # structure is a 2D list where each cell contains wall information
    
    # Get a solution path from start to end
    solution = gen.solve()
    # solution is a list of (x, y) coordinates
    
    # Export to hexadecimal format (compatible with output_validator.py)
    hex_output = gen.to_hex_string()
    
    # Save to file
    gen.save_to_file("maze_output.txt")

Parameters:
    width (int): Width of the maze in cells. Default: 10
    height (int): Height of the maze in cells. Default: 10
    seed (int, optional): Random seed for reproducibility. Default: None
    algorithm (str): Generation algorithm. Options: 'backtracking', 'kruskal', 'prim'. Default: 'backtracking'

Maze Structure Format:
    The internal structure is a 2D grid where each cell is a dictionary with:
    - 'walls': dict with keys 'N', 'E', 'S', 'W' (True = wall present)
    - 'visited': bool indicating if cell was visited during generation
    
    The hexadecimal output format uses 4 bits per cell:
    - Bit 0 (1): North wall open
    - Bit 1 (2): East wall open  
    - Bit 2 (4): South wall open
    - Bit 3 (8): West wall open
    A set bit means the passage is OPEN (no wall).

Author: a-maze project
License: MIT
Version: 1.0.0
"""

import random
from typing import Optional, List, Tuple, Dict, Any
from collections import deque


class MazeGenerator:
    """
    A maze generator class supporting multiple algorithms.
    
    Attributes:
        width (int): The width of the maze in cells.
        height (int): The height of the maze in cells.
        seed (int): The random seed used for generation.
        algorithm (str): The algorithm used for generation.
        
    Example:
        >>> gen = MazeGenerator(width=5, height=5, seed=42)
        >>> gen.generate()
        >>> print(gen.to_hex_string())
    """
    
    # Wall direction constants
    NORTH = 'N'
    EAST = 'E'
    SOUTH = 'S'
    WEST = 'W'
    
    # Direction vectors: (dx, dy)
    DIRECTIONS = {
        'N': (0, -1),
        'E': (1, 0),
        'S': (0, 1),
        'W': (-1, 0)
    }
    
    # Opposite directions
    OPPOSITE = {
        'N': 'S',
        'E': 'W',
        'S': 'N',
        'W': 'E'
    }
    
    def __init__(
        self,
        width: int = 10,
        height: int = 10,
        seed: Optional[int] = None,
        algorithm: str = 'backtracking'
    ):
        """
        Initialize the MazeGenerator.
        
        Args:
            width: Width of the maze in cells (must be >= 2). Default: 10
            height: Height of the maze in cells (must be >= 2). Default: 10
            seed: Random seed for reproducibility. If None, uses system random.
            algorithm: Generation algorithm ('backtracking', 'kruskal', 'prim').
                      Default: 'backtracking'
        
        Raises:
            ValueError: If width or height is less than 2.
            ValueError: If algorithm is not supported.
            
        Example:
            >>> gen = MazeGenerator(width=20, height=15, seed=12345)
        """
        if width < 2:
            raise ValueError(f"Width must be at least 2, got {width}")
        if height < 2:
            raise ValueError(f"Height must be at least 2, got {height}")
        
        supported_algorithms = ['backtracking', 'kruskal', 'prim']
        if algorithm not in supported_algorithms:
            raise ValueError(f"Algorithm must be one of {supported_algorithms}, got '{algorithm}'")
        
        self.width = width
        self.height = height
        self.seed = seed
        self.algorithm = algorithm
        self._grid: List[List[Dict[str, Any]]] = []
        self._generated = False
        self._solution: Optional[List[Tuple[int, int]]] = None
        self._start: Tuple[int, int] = (0, 0)
        self._end: Tuple[int, int] = (width - 1, height - 1)
        
        # Initialize random generator
        self._random = random.Random(seed)
    
    def _init_grid(self) -> None:
        """Initialize the grid with all walls present."""
        self._grid = []
        for y in range(self.height):
            row = []
            for x in range(self.width):
                cell = {
                    'walls': {'N': True, 'E': True, 'S': True, 'W': True},
                    'visited': False
                }
                row.append(cell)
            self._grid.append(row)
    
    def _is_valid(self, x: int, y: int) -> bool:
        """Check if coordinates are within the maze bounds."""
        return 0 <= x < self.width and 0 <= y < self.height
    
    def _remove_wall(self, x1: int, y1: int, x2: int, y2: int, direction: str) -> None:
        """Remove the wall between two adjacent cells."""
        self._grid[y1][x1]['walls'][direction] = False
        self._grid[y2][x2]['walls'][self.OPPOSITE[direction]] = False
    
    def _generate_backtracking(self) -> None:
        """Generate maze using Recursive Backtracking (DFS) algorithm."""
        stack: List[Tuple[int, int]] = []
        start_x, start_y = self._random.randint(0, self.width - 1), self._random.randint(0, self.height - 1)
        
        self._grid[start_y][start_x]['visited'] = True
        stack.append((start_x, start_y))
        
        while stack:
            x, y = stack[-1]
            
            # Get unvisited neighbors
            neighbors = []
            for direction, (dx, dy) in self.DIRECTIONS.items():
                nx, ny = x + dx, y + dy
                if self._is_valid(nx, ny) and not self._grid[ny][nx]['visited']:
                    neighbors.append((nx, ny, direction))
            
            if neighbors:
                # Choose random unvisited neighbor
                nx, ny, direction = self._random.choice(neighbors)
                self._remove_wall(x, y, nx, ny, direction)
                self._grid[ny][nx]['visited'] = True
                stack.append((nx, ny))
            else:
                stack.pop()
    
    def _generate_kruskal(self) -> None:
        """Generate maze using Kruskal's algorithm."""
        # Union-Find data structure
        parent = {}
        
        def find(cell):
            if parent[cell] != cell:
                parent[cell] = find(parent[cell])
            return parent[cell]
        
        def union(cell1, cell2):
            root1, root2 = find(cell1), find(cell2)
            if root1 != root2:
                parent[root1] = root2
                return True
            return False
        
        # Initialize each cell as its own set
        for y in range(self.height):
            for x in range(self.width):
                parent[(x, y)] = (x, y)
                self._grid[y][x]['visited'] = True
        
        # Create list of all walls
        walls = []
        for y in range(self.height):
            for x in range(self.width):
                if x < self.width - 1:
                    walls.append((x, y, x + 1, y, 'E'))
                if y < self.height - 1:
                    walls.append((x, y, x, y + 1, 'S'))
        
        # Shuffle walls
        self._random.shuffle(walls)
        
        # Process walls
        for x1, y1, x2, y2, direction in walls:
            if union((x1, y1), (x2, y2)):
                self._remove_wall(x1, y1, x2, y2, direction)
    
    def _generate_prim(self) -> None:
        """Generate maze using Prim's algorithm."""
        # Start with a random cell
        start_x = self._random.randint(0, self.width - 1)
        start_y = self._random.randint(0, self.height - 1)
        
        self._grid[start_y][start_x]['visited'] = True
        
        # Walls list: (x, y, direction)
        walls = []
        for direction in self.DIRECTIONS:
            walls.append((start_x, start_y, direction))
        
        while walls:
            # Pick a random wall
            idx = self._random.randint(0, len(walls) - 1)
            x, y, direction = walls.pop(idx)
            
            dx, dy = self.DIRECTIONS[direction]
            nx, ny = x + dx, y + dy
            
            # Check if the cell on the other side is unvisited
            if self._is_valid(nx, ny) and not self._grid[ny][nx]['visited']:
                # Remove wall and mark cell as visited
                self._remove_wall(x, y, nx, ny, direction)
                self._grid[ny][nx]['visited'] = True
                
                # Add new walls
                for new_direction in self.DIRECTIONS:
                    ndx, ndy = self.DIRECTIONS[new_direction]
                    nnx, nny = nx + ndx, ny + ndy
                    if self._is_valid(nnx, nny) and not self._grid[nny][nnx]['visited']:
                        walls.append((nx, ny, new_direction))
    
    def generate(self) -> 'MazeGenerator':
        """
        Generate the maze using the configured algorithm.
        
        Returns:
            self: Returns the generator instance for method chaining.
            
        Example:
            >>> gen = MazeGenerator(10, 10, seed=42)
            >>> gen.generate().print_maze()
        """
        self._init_grid()
        self._solution = None
        
        if self.algorithm == 'backtracking':
            self._generate_backtracking()
        elif self.algorithm == 'kruskal':
            self._generate_kruskal()
        elif self.algorithm == 'prim':
            self._generate_prim()
        
        self._generated = True
        return self
    
    def solve(
        self,
        start: Optional[Tuple[int, int]] = None,
        end: Optional[Tuple[int, int]] = None
    ) -> List[Tuple[int, int]]:
        """
        Find a solution path through the maze using BFS.
        
        Args:
            start: Starting position (x, y). Default: (0, 0)
            end: Ending position (x, y). Default: (width-1, height-1)
        
        Returns:
            List of (x, y) coordinates representing the solution path,
            from start to end (inclusive).
        
        Raises:
            RuntimeError: If maze has not been generated yet.
            ValueError: If start or end coordinates are out of bounds.
            
        Example:
            >>> gen = MazeGenerator(10, 10, seed=42)
            >>> gen.generate()
            >>> path = gen.solve()
            >>> print(f"Solution has {len(path)} steps")
        """
        if not self._generated:
            raise RuntimeError("Maze has not been generated yet. Call generate() first.")
        
        if start is None:
            start = self._start
        if end is None:
            end = self._end
        
        if not self._is_valid(start[0], start[1]):
            raise ValueError(f"Start position {start} is out of bounds")
        if not self._is_valid(end[0], end[1]):
            raise ValueError(f"End position {end} is out of bounds")
        
        # BFS to find shortest path
        queue = deque([(start, [start])])
        visited = {start}
        
        while queue:
            (x, y), path = queue.popleft()
            
            if (x, y) == end:
                self._solution = path
                return path
            
            # Check all directions
            for direction, (dx, dy) in self.DIRECTIONS.items():
                nx, ny = x + dx, y + dy
                
                # Check if we can move in this direction (no wall and valid position)
                if (self._is_valid(nx, ny) and 
                    (nx, ny) not in visited and
                    not self._grid[y][x]['walls'][direction]):
                    visited.add((nx, ny))
                    queue.append(((nx, ny), path + [(nx, ny)]))
        
        # No path found (should not happen in a valid maze)
        self._solution = []
        return []
    
    def get_structure(self) -> List[List[Dict[str, Any]]]:
        """
        Get the internal maze structure.
        
        Returns:
            A 2D list (grid[y][x]) where each cell is a dictionary containing:
            - 'walls': dict with keys 'N', 'E', 'S', 'W' (True = wall present)
            - 'visited': bool (internal use)
        
        Raises:
            RuntimeError: If maze has not been generated yet.
            
        Example:
            >>> gen = MazeGenerator(5, 5, seed=42).generate()
            >>> structure = gen.get_structure()
            >>> cell = structure[0][0]  # Top-left cell
            >>> print(cell['walls'])  # {'N': True, 'E': False, 'S': True, 'W': True}
        """
        if not self._generated:
            raise RuntimeError("Maze has not been generated yet. Call generate() first.")
        
        # Return a deep copy to prevent external modification
        import copy
        return copy.deepcopy(self._grid)
    
    def get_solution(self) -> Optional[List[Tuple[int, int]]]:
        """
        Get the last computed solution path.
        
        Returns:
            The solution path as a list of (x, y) coordinates, or None if
            solve() has not been called yet.
            
        Example:
            >>> gen = MazeGenerator(10, 10, seed=42).generate()
            >>> gen.solve()
            >>> path = gen.get_solution()
        """
        return self._solution
    
    def _cell_to_hex(self, x: int, y: int) -> str:
        """Convert a cell's wall configuration to hexadecimal."""
        walls = self._grid[y][x]['walls']
        # Bit 0: North open, Bit 1: East open, Bit 2: South open, Bit 3: West open
        value = 0
        if not walls['N']:
            value |= 1
        if not walls['E']:
            value |= 2
        if not walls['S']:
            value |= 4
        if not walls['W']:
            value |= 8
        return format(value, 'X')
    
    def to_hex_string(self) -> str:
        """
        Convert the maze to hexadecimal string format.
        
        The format is compatible with the output_validator.py script.
        Each cell is represented by a single hex digit (0-F) where:
        - Bit 0 (1): North passage open
        - Bit 1 (2): East passage open
        - Bit 2 (4): South passage open
        - Bit 3 (8): West passage open
        
        Returns:
            A string with one line per row, each cell as a hex digit.
        
        Raises:
            RuntimeError: If maze has not been generated yet.
            
        Example:
            >>> gen = MazeGenerator(3, 3, seed=42).generate()
            >>> print(gen.to_hex_string())
        """
        if not self._generated:
            raise RuntimeError("Maze has not been generated yet. Call generate() first.")
        
        lines = []
        for y in range(self.height):
            line = ''.join(self._cell_to_hex(x, y) for x in range(self.width))
            lines.append(line)
        return '\n'.join(lines)
    
    def save_to_file(self, filepath: str) -> None:
        """
        Save the maze to a file in hexadecimal format.
        
        Args:
            filepath: Path to the output file.
        
        Raises:
            RuntimeError: If maze has not been generated yet.
            
        Example:
            >>> gen = MazeGenerator(10, 10, seed=42).generate()
            >>> gen.save_to_file("maze.txt")
        """
        with open(filepath, 'w') as f:
            f.write(self.to_hex_string())
            f.write('\n')
    
    def print_maze(self, show_solution: bool = False) -> None:
        """
        Print a visual ASCII representation of the maze.
        
        Args:
            show_solution: If True and a solution exists, mark the path with '*'.
        
        Raises:
            RuntimeError: If maze has not been generated yet.
            
        Example:
            >>> gen = MazeGenerator(5, 5, seed=42).generate()
            >>> gen.solve()
            >>> gen.print_maze(show_solution=True)
        """
        if not self._generated:
            raise RuntimeError("Maze has not been generated yet. Call generate() first.")
        
        solution_set = set(self._solution) if show_solution and self._solution else set()
        
        # Top border
        print('+' + '---+' * self.width)
        
        for y in range(self.height):
            # Cell row
            row = '|'
            for x in range(self.width):
                cell_char = ' * ' if (x, y) in solution_set else '   '
                if self._grid[y][x]['walls']['E']:
                    row += cell_char + '|'
                else:
                    row += cell_char + ' '
            print(row)
            
            # Bottom border row
            border = '+'
            for x in range(self.width):
                if self._grid[y][x]['walls']['S']:
                    border += '---+'
                else:
                    border += '   +'
            print(border)
    
    def __repr__(self) -> str:
        """Return a string representation of the generator."""
        status = "generated" if self._generated else "not generated"
        return (f"MazeGenerator(width={self.width}, height={self.height}, "
                f"seed={self.seed}, algorithm='{self.algorithm}', status='{status}')")


# Convenience function for quick maze generation
def generate_maze(
    width: int = 10,
    height: int = 10,
    seed: Optional[int] = None,
    algorithm: str = 'backtracking'
) -> MazeGenerator:
    """
    Convenience function to quickly generate a maze.
    
    Args:
        width: Width of the maze in cells. Default: 10
        height: Height of the maze in cells. Default: 10
        seed: Random seed for reproducibility. Default: None
        algorithm: Generation algorithm. Default: 'backtracking'
    
    Returns:
        A MazeGenerator instance with the maze already generated.
        
    Example:
        >>> from mazegen import generate_maze
        >>> maze = generate_maze(15, 15, seed=42)
        >>> maze.print_maze()
    """
    gen = MazeGenerator(width, height, seed, algorithm)
    gen.generate()
    return gen


if __name__ == '__main__':
    # Demo usage
    print("=== MazeGenerator Demo ===\n")
    
    # Create and generate a maze
    gen = MazeGenerator(width=10, height=8, seed=42)
    gen.generate()
    
    print(f"Generator: {gen}\n")
    
    # Print the maze
    print("Generated Maze:")
    gen.print_maze()
    
    # Solve and show solution
    print("\nSolving maze...")
    solution = gen.solve()
    print(f"Solution path ({len(solution)} steps): {solution[:5]}... (truncated)")
    
    print("\nMaze with solution:")
    gen.print_maze(show_solution=True)
    
    # Show hex output
    print("\nHexadecimal output (for output_validator.py):")
    print(gen.to_hex_string())
