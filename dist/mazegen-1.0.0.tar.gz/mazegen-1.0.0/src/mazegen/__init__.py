"""
mazegen - A reusable maze generation library.

This package provides the MazeGenerator class for generating random mazes
using various algorithms including Recursive Backtracking, Kruskal's, and Prim's.

Quick Start:
    >>> from mazegen import MazeGenerator
    >>> gen = MazeGenerator(width=10, height=10, seed=42)
    >>> gen.generate()
    >>> gen.print_maze()
    >>> solution = gen.solve()

For more information, see the MazeGenerator class documentation.
"""

from .maze_generator import MazeGenerator, generate_maze

__version__ = "1.0.0"
__all__ = ["MazeGenerator", "generate_maze"]
